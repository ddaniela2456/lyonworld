// Rust smart contract main file
use anchor_lang::prelude::*;

#[program]
mod lyon_referral {
    use super::*;
    pub fn purchase(ctx: Context<Purchase>, usdt_amount: u64, referrer: Pubkey) -> Result<()> {
        Ok(())
    }
}